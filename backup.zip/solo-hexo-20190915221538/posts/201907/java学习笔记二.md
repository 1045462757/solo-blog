title: java学习笔记二
date: '2019-07-17 11:10:01'
updated: '2019-07-17 11:11:15'
tags: [java, 学习]
permalink: /articles/2019/07/17/1563333001902.html
---
![wallhaven406.jpg](https://img.hacpai.com/file/2019/07/wallhaven406-43a9d1b8.jpg)

## java学习笔记二

### String,StringBuffer,StringBuilder的区别

------

* String

  String是一种特殊的对象，一旦初始化就不可改变

  创建字符串的两种方式:

  ```java
  String str = "hello world";
  String str = new String("hello world");
  ```

  两种方式的区别

  * 使用String直接赋值

    String str = "Hello world"; 

    可能创建一个或者不创建对象。

    如果"Hello world"在**字符串常量池**中不存在，则会在java字符串常量池创建一个String对象，然后str指向这个对象的内存地址；如果“Hello world”在字符串常量池中存在，str直接指向这个地址。

    **常量池**:在编译期被确定，并被保存在已编译的.class文件中的一些数据，它包括了关于类，方法，接口等中的常量，也包括字符串常量。

    **字符串常量池**:存储字符串常量的内存空间，当需要使用字符串时，先去字符串常量池中查看该字符串是否已经存在，如果存在，则可以直接使用，如果不存在，初始化，并将该字符串放入字符串常量池中。

  * 使用new String创建字符串

    String str = new String("Hello world")；至少会创建一个对象，也有可能创建两个。new关键字肯定会在堆内存中创建一个String对象，如果字符串常量池中已经存在“Hello world”，则不会在字符串常量池中创建一个String对象，如果不存在，则会在字符串常量池中也创建一个对象。
    
    
    
    参考
    
    [JAVA--String str=""与new String()的区别](https://blog.csdn.net/xin6yang/article/details/88842671)
    
    ------
    
    

* StringBuffer

  线程安全的字符串操作类
  
  例子
  
  ```java
  StringBuffer sb = new StringBuffer();
  sb.append("da");
  sb.append("shu");
  System.out.println(sb);
  ```
  
  
  
  ------
  
  
  
* StringBuilder

  线程不安全的字符串操作类
  
  
  
  ------
  
  
  
* 结论

  日常开发中，如何选择一个合适的字符串操作类?

  * 如果你要求字符串不可变，那么应该选择String类
  * 如果你需要字符串可变并且是线程安全的，那么你应该选择StringBuffer类
  * 如果你要求字符串可变并且不存在线程安全问题，那么你应该选择StringBuilder类