title: Mysql学习笔记二
date: '2019-07-20 10:36:14'
updated: '2019-07-20 15:25:29'
tags: [学习, mysql]
permalink: /articles/2019/07/20/1563590174309.html
---
![wallhaven212014.png](https://img.hacpai.com/file/2019/07/wallhaven212014-194b7189.png)

# Mysql学习笔记二

## 1.SQL

* 定义

  * **Structured Query Language 结构化查询语言**

    定义了操作关系型数据库的规则，每一种数据库操作方式存在不一样的地方，称为**数据库方言**。

* 分类

  * **DDL**(Data Definition Language) 数据定义语言

    用来定义数据库对象：数据库，表，列等。关键字：create,drop,alter

  * **DML**(Data Manipulation Language) 数据操作语言

    用来对数据库中表的数据进行增删改。关键字：insert,delete,update等

  * **DQL**(Data Query Language) 数据查询语言

    用来查询数据库中表的记录。关键字:select,where等

  * **DCL**(Data Control Language) 数据控制语言

    用来定义数据库的访问权限和安全级别，及创建用户。关键字：Grant,Revoke等

------



## 2.DDL

**定义数据库对象**

* 数据库
* 表
* 列



### 2.1 数据库操作

------

#### 2.1.1 创建数据库

~~~mysql
#创建数据库，db_name为数据库名
create database db_name;

#判断数据库是否存在，不存在则创建数据库
create database if not exists db_name;

#创建数据库时设置字符集,char_name为字符集名
create database db_name character set char_name
~~~

示例:

~~~mysql
 mysql>create database if not exists db1 character set utf8;
 Query OK, 1 row affected (0.00 sec)
~~~



#### 2.1.2 查询数据库

```mysql
#查看所有数据库
show databases;
```

示例:

```mysql
mysql> show databases;
+--------------------+
| Database           |
+--------------------+
| information_schema |
| mysql              |
| performance_schema |
| solo               |
| sys                |
| world              |
| db1                |
+--------------------+
7 rows in set (0.00 sec)
```



~~~mysql
#查看数据库的字符集
show create database db_name;
~~~

示例:

~~~mysql
mysql> show create database db1;
+----------+--------------------------------------------------------------+
| Database | Create Database                                              |
+----------+--------------------------------------------------------------+
| db1      | CREATE DATABASE `db1` /*!40100 DEFAULT CHARACTER SET utf8 */ |
+----------+--------------------------------------------------------------+
1 row in set (0.00 sec)
~~~



~~~mysql
#查询当前正在使用的数据库连接
select database();
~~~

示例:

~~~mysql
mysql> select database();
+------------+
| database() |
+------------+
| db1        |
+------------+
1 row in set (0.00 sec)
~~~



#### 2.1.3 使用数据库

```mysql
#使用某个数据库，db_name为数据库名
use db_name;
```

示例:

~~~mysql
mysql> use solo
Database changed
~~~



#### 2.1.4 修改数据库

```mysql
#修改数据库的字符集
alter database db_name character set char_name;
```

示例:

~~~mysql
mysql> alter database db1 character set gbk;
Query OK, 1 row affected (0.00 sec)
~~~



#### 2.1.5 删除数据库

~~~mysql
#删除数据库
drop database db_name;

##判断数据库是否存在，存在则删除数据库
drop database if exists db_name;
~~~

示例:

~~~mysql
mysql> drop database db1;
Query OK, 0 rows affected (0.01 sec)
~~~

------



### 2.2 表操作

#### 2.2.1 创建表

```mysql
#创建表,注意最后一列不需要加逗号,col_name为字段名，datatype为数据库类型
create table table_name(
	col_name1 datatype,
	col_name2 datatype,
	......
	col_namen datatype
);
```

常见的数据库类型

- int：整数类型
  - age int
- double：小数类型
  - score double(5,2);
- date：日期，只包含年月日，yyyy-mm--dd
- datetime：日期 ,包含年月日时分秒,yyyy-mm-dd HH:mm:ss
- timestamp:时间戳类型，包含年月日时分秒
  - 不给这个字段赋值或赋值为null，则默认使用系统当前时间
- varchar:字符串
  - name:varchar(20),姓名最大20个字符



示例:

~~~mysql
#创建学生表
mysql>create table student(
	id int,
	name varchar(32),
	age int,
	score double(4,1),
	birthday date,
	insert_time timestamp
);
Query OK, 0 rows affected (0.02 sec)

#创建班级表
mysql> create table class(id int,name varchar(20));
Query OK, 0 rows affected (0.02 sec)
~~~



#### 2.2.2 查询表

```mysql
#查询某个数据库的所有的表
show tables;
```

示例:

~~~mysql
mysql> show tables;
+---------------+
| Tables_in_db1 |
+---------------+
| class         |
| stu           |
+---------------+
2 rows in set (0.00 sec)
~~~



~~~mysql
#查询表结构,table_name为表名
desc table_name;
~~~

示例:

~~~mysql
mysql> desc stu;
+-------------+-------------+------+-----+-------------------+-----------------------------+
| Field       | Type        | Null | Key | Default           | Extra                       |
+-------------+-------------+------+-----+-------------------+-----------------------------+
| id          | int(11)     | YES  |     | NULL              |                             |
| name        | varchar(32) | YES  |     | NULL              |                             |
| age         | int(11)     | YES  |     | NULL              |                             |
| score       | double(4,1) | YES  |     | NULL              |                             |
| birthday    | date        | YES  |     | NULL              |                             |
| insert_time | timestamp   | NO   |     | CURRENT_TIMESTAMP | on update CURRENT_TIMESTAMP |
+-------------+-------------+------+-----+-------------------+-----------------------------+
6 rows in set (0.00 sec)
~~~



~~~mysql
#查看表的字符集
show create table table_name;
~~~

示例:

~~~mysql
mysql> show create table stu;
+-------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| Table | Create Table                                                                                                                                                                                                                                                                                                                           |
+-------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
| stu   | CREATE TABLE `stu` (
  `id` int(11) DEFAULT NULL,
  `name` varchar(32) CHARACTER SET utf8 DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `score` double(4,1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `insert_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=gbk |
+-------+----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------+
1 row in set (0.00 sec)
~~~



#### 2.2.3 修改表

~~~mysql
#修改表名
alter table table_name rename to new_table_name;
~~~

示例:

~~~mysql
mysql> alter table stu rename to student;
Query OK, 0 rows affected (0.01 sec)
~~~



~~~mysql
#修改表的字符集
alter table table_name character set char_name;
~~~

示例:

~~~mysql
mysql> alter table class character set gbk;
Query OK, 0 rows affected (0.01 sec)
~~~



#### 2.2.4 删除表

~~~mysql
#删除表
drop table table_name;
~~~

示例:

~~~mysql
mysql> drop table class;
Query OK, 0 rows affected (0.01 sec)
~~~

------



### 2.3 列操作

#### 2.3.1 创建列

~~~mysql
#创建列
alter table table_name add col_name datatype;
~~~

示例:

~~~mysql
mysql> alter table student add class_id int;
Query OK, 0 rows affected (0.07 sec)
~~~



#### 2.3.2 修改列

~~~mysql
#修改列的名称和数据类型
alter table table_name change col_name new_col_name datatype;

#修改列的数据类型
alter table table_name modify col_name datatype;
~~~

示例:

~~~mysql
mysql> alter table student change birthday birth date;
Query OK, 0 rows affected (0.01 sec)

mysql> alter table student modify name varchar(24);
Query OK, 0 rows affected (0.05 sec)
~~~



#### 2.3.3 删除列

~~~mysql
#删除列
alter table table_name drop col_name;
~~~

示例:

~~~mysql
mysql> alter table student drop class_id;
Query OK, 0 rows affected (0.06 sec)
~~~

------



## 3.DML

对表中的数据增删改



### 3.1 增加数据

```mysql
#增加数据
insert into table_name (col_name1,col_name2,...col_namen) values (value1,value2,...valuen);
```

示例:

~~~mysql
mysql> insert into student (id,name,age,score) values (1,"张三",20,88.5);
Query OK, 1 row affected (0.00 sec)
~~~



```mysql
#添加所有数据
insert into table_name values(value1,value2,...valuen);
```

注意事项：

- 列名和值要一一对应
- 如果表名后不定义列名，则默认给所有列添加值
- 除了数字类型，其他类型需要使用引号



示例:

~~~mysql
mysql> insert into student values (5,"李四",21,90.5,"1998-08-23",null);
Query OK, 1 row affected (0.00 sec)
~~~



### 3.2 删除数据

```mysql
#condition为条件，不加条件，则删除所有数据
delete from table_name where condition;
```

示例:

~~~mysql
mysql> delete from student where id =1;
Query OK, 1 row affected (0.00 sec)
~~~



```mysql
#先删除表，然后创建一个一模一样的表
truncate table_name;
```

示例:

~~~mysql
mysql> truncate student;
Query OK, 0 rows affected (0.01 sec)
~~~



### 3.3 修改数据

~~~mysql
#不加条件会将所有的记录全部修改
update table_name set col_name1 = value1,col_name2 = value2,...col_namen = valuen where conditon;
~~~

示例:

~~~mysql
mysql> update student set name = "王二" where id = 1;
~~~

------

## 4.DQL

### 4.1 简单查询

~~~mysql
#语法
select 字段
	from 表
		where 条件
			group by 字段
				having 条件
					order by 排序
						limit 分页
~~~



```mysql
#去重
select distinct col_name from table_name
```



```mysql
#字段可以进行简单运算，as可起别名，有null参与的运算，计算结果都为null
select col_name1,col_name2,col_name1+col_name2 as other_name from table_name

#置换null，x为置换的值
select col_name1,col_name2,col_name1+IFNULL(col_name,x) from table_name;
```



```mysql
#数值之间查询
select * from table_name where col_name between xx and xx
```



```mysql
#查询给定条件
select * from table_name where col_name in (x,x,x);
```



~~~mysql
#判断字段是否为null
select * from table_name where col_name is null;
select * from table_name where col_name is not null;
~~~



~~~mysql
#模糊查询，_一个占位符，%多个占位符
select * from table_name where col_name like '%x%'
~~~



### 4.2 排序查询

```mysql
#排序查询，asc升序，默认，desc降序，字段优先级逐级降低
order by col_name1 type,col_nmae2 type,...col_namen type;
```



### 4.3 聚合函数

将一列数据作为一个整体，进行纵向的计算

注意:排除null值 ,解决方案：1.选择不包含非空的列进行计算2.IFNULL函数

* count 计算个数

  ~~~mysql
  #count
  select count(col_name) from table_name;
  select count(IFNULL(col_name,x)) from table_name;
  select count(*) from table_name;
  ~~~

* max 计算最大值

  ~~~mysql
  #max
  select max(col_name) from table_name;
  ~~~

* min 计算最小值

  ~~~mysql
  #min
  select min(col_name) from table_name;
  ~~~

* sum 计算和

  ~~~mysql
  #sum
  select sum(col_name) from table_name;
  ~~~

* avg 计算平均值

  ~~~mysql
  #avg
  select avg(col_name) from table_name;
  ~~~



### 4.4 分组查询

 * 语法

    * group by 分组字段；	

    * 注意:分组之后的查询字段：分组字段，聚合函数

     ```mysql
      #分组查询
      select col_name from table_name group by col_name;
     ```
      
      ```mysql
      #分组条件
      select col_name from table_name where condition group by col_name;
      ```

      
      
      ```mysql
      #分组查询之后的条件判断
      select col_name from table_name group by col_name having condition;
     ```
      

      
      where和having的区别
      
      1.where 在分组之间进项限定，如果不满足条件，则不参与分组。having在分组之后进行限定，如果不满足结果，则不会被查询出来
      
      2.where后不可跟聚合函数，having可以进行聚合函数的判断（where后若跟聚合函数统计所有数据后则无法分组）
      
      

### 4.5 分页查询

~~~mysql
#index为开始的索引，size为数据条数
select * from table_name limit index,size;
~~~

公式：开始的索引 = (当前的页码-1)*每页显示的数据条数

limit:是一个mysql方言

