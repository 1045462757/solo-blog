title: java克隆
date: '2019-08-27 13:55:17'
updated: '2019-08-27 13:58:05'
tags: [java, 学习]
permalink: /articles/2019/08/27/1566885316801.html
---
![](https://img.hacpai.com/bing/20171230.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# java克隆

## 1.什么是克隆

**拷贝一个新对象，与原来的对象完全一致互不影响**



## 2.为什么需要克隆

**想对一个对象进行处理，又想保留原有的数据进行接下来的操作，就需要克隆了，克隆的对象可能包含一些已经修改过的属性，而new出来的对象的属性都还是初始化时候的值，所以当需要一个新的对象来保存当前对象的“状态”就靠clone方法了。那么我把这个对象的临时属性一个一个的赋值给我新new的对象不也行嘛？可以是可以，但是一来麻烦不说，二来，clone是一个native方法，在底层实现的，速度快。**



## 3.克隆的种类

* 浅度克隆
   只拷贝对象本身，不包含对象的引用
* 深度克隆
   既包含对象本身，也包含对象的引用



## 4.克隆的实现

*  实现Cloneable接口并重写Object类中的clone()方法
*  实现Serializable接口，通过对象的序列化和反序列化实现克隆，可以实现真正的深度克隆



### Cloneable接口实现

~~~java

/**
 * 班级类
 */
public class Clazz implements Cloneable {

    private String name;

    public Clazz(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}


/**
 * 学生类
 */
public class Student implements Cloneable{

    private String name;

    private int age;

    private String sex;

    private Clazz clazz;

    @Override
    protected Object clone() throws CloneNotSupportedException {
        Student student = (Student) super.clone();
        student.setClazz((Clazz) clazz.clone());
        return student;
    }

    public Student(String name, int age, String sex, Clazz clazz) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.clazz = clazz;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Clazz getClazz() {
        return clazz;
    }

    public void setClazz(Clazz clazz) {
        this.clazz = clazz;
    }

    public static void main(String args[]) {
        Clazz clazz = new Clazz("一班", 1);
        Student student = new Student("张三", 18, "男", clazz);

        Student student1 = null;
        try {
            student1 = (Student) student.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }


        System.out.println("name:" + student.getName() + ",age:" + student.getAge() + ",sex:" + student.getSex() + ",clazz:" + student.getClazz().getName());

        System.out.println("name:" + student1.getName() + ",age:" + student1.getAge() + ",sex:" + student1.getSex() + ",clazz:" + student1.getClazz().getName());

        student.setName("李四");
        clazz.setName("二班");

        System.out.println("修改后");

        System.out.println("name:" + student.getName() + ",age:" + student.getAge() + ",sex:" + student.getSex() + ",clazz:" + student.getClazz().getName());

        System.out.println("name:" + student1.getName() + ",age:" + student1.getAge() + ",sex:" + student1.getSex() + ",clazz:" + student1.getClazz().getName());

        System.out.println(student == student1);
        System.out.println(student.clazz == student1.clazz);
    }
}


//运行结果
name:张三,age:18,sex:男,clazz:一班
name:张三,age:18,sex:男,clazz:一班
修改后
name:李四,age:18,sex:男,clazz:二班
name:张三,age:18,sex:男,clazz:一班
false
false

~~~



### Serializable接口实现

~~~java
/**
 * 班级类
 */
import java.io.Serializable;

public class Clazz implements Serializable {

    private String name;

    public Clazz(String name, int code) {
        this.name = name;
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}


/**
 * 学生类
 */
import java.io.*;

public class Student implements Serializable {

    private String name;

    private int age;

    private String sex;

    private Clazz clazz;

    public Student myClone() {
        Student student = null;
        try { // 将该对象序列化成流,因为写在流里的是对象的一个拷贝，而原对象仍然存在于JVM里面。所以利用这个特性可以实现对象的深拷贝
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(this);
            // 将流序列化成对象
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            student = (Student) ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return student;
    }

    public Student(String name, int age, String sex, Clazz clazz) {
        this.name = name;
        this.age = age;
        this.sex = sex;
        this.clazz = clazz;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Clazz getClazz() {
        return clazz;
    }

    public void setClazz(Clazz clazz) {
        this.clazz = clazz;
    }

    public static void main(String args[]) {
        Clazz clazz = new Clazz("一班", 1);
        Student student = new Student("张三", 18, "男", clazz);

        Student student1 = student.myClone();

        System.out.println("name:" + student.getName() + ",age:" + student.getAge() + ",sex:" + student.getSex() + ",clazz:" + student.getClazz().getName());

        System.out.println("name:" + student1.getName() + ",age:" + student1.getAge() + ",sex:" + student1.getSex() + ",clazz:" + student1.getClazz().getName());

        student.setName("李四");
        clazz.setName("二班");

        System.out.println("修改后");

        System.out.println("name:" + student.getName() + ",age:" + student.getAge() + ",sex:" + student.getSex() + ",clazz:" + student.getClazz().getName());

        System.out.println("name:" + student1.getName() + ",age:" + student1.getAge() + ",sex:" + student1.getSex() + ",clazz:" + student1.getClazz().getName());

        System.out.println(student == student1);
        System.out.println(student.clazz == student1.clazz);
    }
}


//运行结果
name:张三,age:18,sex:男,clazz:一班
name:张三,age:18,sex:男,clazz:一班
修改后
name:李四,age:18,sex:男,clazz:二班
name:张三,age:18,sex:男,clazz:一班
false
false

~~~



