title: vue项目的构建
date: '2019-07-16 16:00:50'
updated: '2019-07-17 11:10:54'
tags: [vue, 学习]
permalink: /articles/2019/07/16/1563264049956.html
---
![wallhavenyjqyrd.jpg](https://img.hacpai.com/file/2019/07/wallhavenyjqyrd-f8bde4d4.jpg)

## 1.安装vue-cli
* 要有node.js环境支持

查看node.js的版本
```
node-v
```
![image.png](https://img.hacpai.com/file/2019/07/image-7834c3d6.png)


查看npm的版本
```
npm-v
```
![image.png](https://img.hacpai.com/file/2019/07/image-b6c0f508.png)

* 安装webpack
```
npm install webpack -g
```

查看webpack版本
```
 webpack-v
```
![image.png](https://img.hacpai.com/file/2019/07/image-693e1d49.png)

* 安装vue-cli
```
npm install --global vue-cli
```

查看vue版本
```
vue -V
```
![image.png](https://img.hacpai.com/file/2019/07/image-591baa91.png)

## 2.vue-cli构建项目
demo为项目文件夹
```
vue init webpack demo
```
  配置完成后cd进入文件夹内部安装依赖
```
cd demo
npm install
```


## 3.启动项目
```
npm run dev
```
ctrl+c退出


## 4.项目打包
```
npm run build
```


