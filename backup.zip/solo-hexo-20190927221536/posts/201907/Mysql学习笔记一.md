title: Mysql学习笔记一
date: '2019-07-18 16:38:45'
updated: '2019-07-18 16:38:45'
tags: [学习, mysql]
permalink: /articles/2019/07/18/1563439125754.html
---
![wallhaven4d9v2m.jpg](https://img.hacpai.com/file/2019/07/wallhaven4d9v2m-813b0304.jpg)

# Mysql学习笔记一

## 1.数据库的基本概念

**用于存储和管理数据的仓库**

## 2.数据库的特点

* 持久化存储数据
* 方便存储和管理数据
* 使用统一的方式操作数据库

## 3.mysql的卸载

* 去mysql的安装目录找到my.ini文件
* 复制datadir目录
* 删除datadir目录

## 4.mysql启动

* cmd

  ```shell
  services.msc
  ```
![image.png](https://img.hacpai.com/file/2019/07/image-1e96b2a6.png)


  找到mysql启动

* 管理员cmd 

  启动mysql

  ```shell
  net start mysql
  ```

  停止mysql

  ```shell
  net stop mysql
  ```

  可能会遇到服务名无效的问题

  .管理员进入mysql的bin目录

  ```shell
  mysqld --install
  ```

## 5.连接与退出mysql

连接mysql，username为mysql的用户名,password为密码

```shell
mysql -u(username) -p(password)
```

远程连接mysql，ip为主机ip，username为主机上的mysql的用户名,password为主机上的mysql的密码

```shell
mysql -h(ip) -u(username) -p(password)
```

退出mysql连接

```shell
exit
```



