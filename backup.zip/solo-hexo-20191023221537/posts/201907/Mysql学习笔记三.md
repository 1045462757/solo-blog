title: Mysql学习笔记三
date: '2019-07-20 16:54:40'
updated: '2019-07-20 16:54:40'
tags: [学习, mysql]
permalink: /articles/2019/07/20/1563612880608.html
---
![wallhavenmdldm8.jpg](https://img.hacpai.com/file/2019/07/wallhavenmdldm8-20b30816.jpg)

# Mysql学习笔记三

## 1.约束

* 概念:对表中的数据进行限定，保证数据的正确性，有效性和完整性。
* 分类
  * 主键约束 : primary key
  * 非空约束 : not null
  * 唯一约束 : unique
  * 外键约束 : foreign key

------





## 2.非空约束

~~~mysql
#创建表时添加非空约束
create table table_name(
	col_name datatype NOT NULL
);
~~~



~~~mysql
#创建表完后，添加非空约束
alter table table_name modify col_name datatype NOT NULL;
~~~



~~~mysql
#删除非空约束
alter table table_name modify col_name datatype;
~~~



------



## 3.唯一约束

~~~mysql
#创建表时添加唯一约束
create table table_name(
	col_name datatype UNIQUE
);
~~~



~~~mysql
#创建表后，添加唯一约束
alter table table_name modify col_name datatype UNIQUE
~~~



~~~mysql
#删除唯一约束
alter table table_name drop index col_name;
~~~



------



## 4.主键约束

* 含义:非空且唯一
* 一张表只能有一个字段为主键
* 主键就是表中记录的唯一标识



~~~mysql
#创建表时，添加主键约束
create table table_name(
	col_name datatype PRIMARY KEY
);
~~~



~~~mysql
#创建表后，添加主键约束
alter table table_name modify col_name datatype PRIMARY KEY;
~~~



~~~mysql
#删除主键约束
alter table table_name drop PRIMARY KEY
~~~



自动增长：如果某一列数据类型是数值，使用auto_increment可以完成值的自动增长

~~~mysql
#创建表时设置主键自动增长
create table table_name(
	col_name datatype PRIMARY KEY AUTO_INCREMENT
);
~~~



~~~mysql
#创建表后，设置主键自动增长
alter table table_name modify col_name datatype AUTO_INCREMENT；
~~~



~~~mysql
#删除自动增长
alter table table_name modify col_name datatype
~~~



------



## 5.外键约束

概念：让表与表产生关系，从而保证数据的正确性



~~~mysql
#创建表时添加外键约束
create table table_name(
	...
	CONSTRAINT 外键名称 FOREIGN KEY (外键列名称) REFERENCES 主表名称(主表列名称)
);
~~~



~~~mysql
#创建表之后，添加外键约束
alter table table_name add CONSTRAINT 外键名称 FOREIGN KEY (外键列名称) REFERENCES 主表名称(主表列名称)
~~~



~~~mysql
#删除外键约束
alter table table_name drop FOREIGN KEY 外键名称
~~~



级联操作

* 分类:

  * 级联更新:ON UPDATE CASCADE

  * 级联删除:ON DELETE CASCADE

    

~~~mysql
#添加级联操作
alter table table_name add CONSTRAINT 外键名称 FOREIGN KEY (外键列名称) REFERENCES 主表名称(主表列名称) ON UPDATE CASCADE
~~~

