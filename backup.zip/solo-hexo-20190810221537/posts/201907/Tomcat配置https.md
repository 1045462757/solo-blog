title: Tomcat配置https
date: '2019-07-17 22:33:50'
updated: '2019-07-17 22:35:21'
tags: [项目记录, tomcat]
permalink: /articles/2019/07/17/1563374030383.html
---
![wallhaven496144.jpg](https://img.hacpai.com/file/2019/07/wallhaven496144-90a833c0.jpg)

Tomcat 版本 9.0.22

server.xml配置，注意将redirectPort设为443

80端口配置
```
<Connector  port="80"  protocol="HTTP/1.1"  connectionTimeout="20000"  redirectPort="443"  />
```

443端口配置
```
<Connector  port="443"  protocol="org.apache.coyote.http11.Http11NioProtocol"

maxThreads="150"  SSLEnabled="true">

<SSLHostConfig>

<Certificate  certificateKeystoreFile="conf/xxx.jks"

type="RSA"  certificateKeystorePassword="xxxxxx"  />

</SSLHostConfig>

</Connector>
```

web.xml配置，设置http访问转发为https
welcome-file-list之后添加下列代码（文件末尾）
```
<login-config>

<!-- Authorization setting for SSL -->

<auth-method>CLIENT-CERT</auth-method>

<realm-name>Client Cert Users-only Area</realm-name>

</login-config>

<security-constraint>

<!-- Authorization setting for SSL -->

<web-resource-collection  >

<web-resource-name  >SSL</web-resource-name>

<url-pattern>/*</url-pattern>

</web-resource-collection>

<user-data-constraint>

<transport-guarantee>CONFIDENTIAL</transport-guarantee>

</user-data-constraint>

</security-constraint>
```

Tomcat 8及以下版本

tomcat8及8一下的版本配置的是keystoreFile="conf/.jks"和keystorePass="xxxxxx"）
```
<Connector port="443" protocol="HTTP/1.1" SSLEnabled="true"
    maxThreads="150" scheme="https" secure="true"
    keystoreFile="conf/xxx.jks"
    keystorePass="xxxxxx"
    clientAuth="false" sslProtocol="TLS" />

```