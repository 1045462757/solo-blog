title: java学习笔记一
date: '2019-07-16 14:27:32'
updated: '2019-07-16 14:35:28'
tags: [java, 学习]
permalink: /articles/2019/07/16/1563258452274.html
---
![wallhaven10544.jpg](https://img.hacpai.com/file/2019/07/wallhaven10544-b2898f5b.jpg)

# java学习笔记一

### java基本数据类型

java语言提供了八种基本类型。

六种数字类型（四个整数型，两个浮点型），一种字符类型，一种布尔类型。

- byte：8位，1字节，有符号的整数

  最小值是 -128

  最大值是 127

  默认值是 0

  byte类型用在大型数组中节约空间，主要代替整数，因为byte变量占用的空间只有int类型的四分之一

  例子： byte a =100;  byte b= -50;

- short : 16位，2字节，有符号的整数

  最小值是 -32768

  最大值是 32767

  默认值是 0 

  short类型也可以像byte那样节省空间，一个short变量是int变量所占空间的二分之一

  例子：short s =1000; short r = -20000;

- int : 32位，4字节，有符号的整数

  最小值是 -2,147,483,648(21亿)

  最大值是 2,147,483,647

  默认值是 0

  例子：int a = 10000; int b = 20000;

- long : 64位，8字节。有符号的整数

  最小值 -9,233,372,035,854,775,808

  最大值 9,233,372,035,854,775,807

  默认值是 0

  例子 long a = 10000L; long b = 99999L;

- float: 32位，4字节，浮点数

  默认值是 0.0f

  float在储存大型浮点数组的时候可节省内存空间

  浮点数不能用来表示精确的值

  例子：float f = 234.5f；

- double:64位，8字节，浮点数

  默认值是 0.0d

  例子: double d = 123.4

- boolean: 1位

  默认值： false

  例子 : boolean b = true;

- char: 16位，2字节 

  最小值：\u0000(0)

  最大值:\uffff(65535)

  char数据类型可以存储任何字符

  例子: char a = 'A';



### 自动装箱与拆箱

基本数据类型都有对应的包装类型，基本类型与其对应的包装类型之间的赋值使用自动装箱与拆箱完成。

#### 定义

java中基础数据类型与它们的包装类进行运算时，编译器会自动帮助我们进行转换。

装箱:自动根据基本数据类型创建对应的包装类对象。

拆箱:自动将包装类对象转换成基本数据类型。

#### 实现

装箱:调用包装类的**valueOf(xx)**方法,xx是基本数据类型。

拆箱:调用包装的**xxValue()**方法,xx是基本数据类型。

#### 常见面试题

```java
public class Main {
    public static void main(String[] args) {
         
        Integer i1 = 100;
        Integer i2 = 100;
        Integer i3 = 200;
        Integer i4 = 200;
         
        System.out.println(i1==i2);
        System.out.println(i3==i4);
    }
}
```

输出结果

```java
true
false
```

输出结果表明i1和i2指向同一个对象，i3和i4指向不同的对象。

这是Integer的valueOf源码

```java
public static Integer valueOf(int i) {
        if(i >= -128 && i <= IntegerCache.high)
            return IntegerCache.cache[i + 128];
        else
            return new Integer(i);
    }
```

其中IntegerCache类的源码

```java
 private static class IntegerCache {
        static final int high;
        static final Integer cache[];

        static {
            final int low = -128;

            // high value may be configured by property
            int h = 127;
            if (integerCacheHighPropValue != null) {
                // Use Long.decode here to avoid invoking methods that
                // require Integer's autoboxing cache to be initialized
                int i = Long.decode(integerCacheHighPropValue).intValue();
                i = Math.max(i, 127);
                // Maximum array size is Integer.MAX_VALUE
                h = Math.min(i, Integer.MAX_VALUE - -low);
            }
            high = h;

            cache = new Integer[(high - low) + 1];
            int j = low;
            for(int k = 0; k < cache.length; k++)
                cache[k] = new Integer(j++);
        }

        private IntegerCache() {}
    }
```

通过这两段代码可以看出，**<u>在通过valueOf创建Integer对象的时候，如果数值在[-128,127]之间，便返回指向IntegerCache.cache中已经存在的对象的引用，否则创建一个新的Integer对象</u>**

------



```java
public class Main {
    public static void main(String[] args) {
         
        Double i1 = 100.0;
        Double i2 = 100.0;
        Double i3 = 200.0;
        Double i4 = 200.0;
         
        System.out.println(i1==i2);
        System.out.println(i3==i4);
    }
}
```

输出结果

```java
false
false
```

为什么Double类的valueOf方法不同于Integer类的valueOf方法？

**<u>因为在某个范围内的整型数值的个数是有限的，而浮点数则不是</u>**

注意，Integer、Short、Byte、Character、Long这几个类的valueOf方法的实现是类似的。

Double、Float的valueOf方法的实现是类似的。

------

```java
public class Main {
    public static void main(String[] args) {
         
        Boolean i1 = false;
        Boolean i2 = false;
        Boolean i3 = true;
        Boolean i4 = true;
         
        System.out.println(i1==i2);
        System.out.println(i3==i4);
    }
}
```

输出结果

```java
true
true
```

Boolean的valueOf源码

```java
public static Boolean valueOf(boolean b) {
        return (b ? TRUE : FALSE);
    }
```

------

谈谈Integer i = new Integer(xxx) 和 Integer i = xxx; 两种方式的区别

主要有以下两点区别:

1.第一种方式不会触发自动装箱的过程，而第二种会触发

2.在执行效率和资源占用上的区别，第二种方式的执行效率和资源占用在一般情况下要优于第一种情况(但这并不绝对)

------

```java
public class Main {
    public static void main(String[] args) {
         
        Integer a = 1;
        Integer b = 2;
        Integer c = 3;
        Integer d = 3;
        Integer e = 321;
        Integer f = 321;
        Long g = 3L;
        Long h = 2L;
         
        System.out.println(c==d);
        System.out.println(e==f);
        System.out.println(c==(a+b));
        System.out.println(c.equals(a+b));
        System.out.println(g==(a+b));
        System.out.println(g.equals(a+b));
        System.out.println(g.equals(a+h));
    }
}
```

输出结果

```java
true
false
true
true
true
false
true
```

需要注意的是：当 "=="运算符的两个操作数都是 包装器类型的引用，则是比较指向的是否是同一个对象，而如果其中有一个操作数是表达式（即包含算术运算）则比较的是数值（即会触发自动拆箱的过程）。另外，对于包装器类型，equals方法并不会进行类型转换。

第一个和第二个输出结果没有什么疑问。第三句由于  a+b包含了算术运算，因此会触发自动拆箱过程（会调用intValue方法），因此它们比较的是数值是否相等。而对于c.equals(a+b)会先触发自动拆箱过程，再触发自动装箱过程，也就是说a+b，会先各自调用intValue方法，得到了加法运算后的数值之后，便调用Integer.valueOf方法，再进行equals比较。同理对于后面的也是这样，不过要注意倒数第二个和最后一个输出的结果（如果数值是int类型的，装箱过程调用的是Integer.valueOf；如果是long类型的，装箱调用的Long.valueOf方法）。

------

参考
[深入剖析Java中的装箱和拆箱](https://www.cnblogs.com/dolphin0520/p/3780005.html)